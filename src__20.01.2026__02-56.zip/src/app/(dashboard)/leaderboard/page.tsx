import { Title, Text } from '@mantine/core';

export default function LeaderboardPage() {
  return (
    <div>
      <Title order={1}>Leaderboard</Title>
      <Text c="var(--color-foreground-muted)" size="sm" mt={4}>
        COMING SOOM...
      </Text>
    </div>
  );
}