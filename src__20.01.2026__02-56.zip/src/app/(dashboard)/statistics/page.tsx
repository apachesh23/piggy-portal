import { Title, Text, Card, SimpleGrid } from '@mantine/core';

export default function StatisticsPage() {
  return (
    <div>
      <Title order={1}>Me statistic</Title>
      <Text c="var(--color-foreground-muted)" size="sm" mt={4}>
        COMING SOOM...
      </Text>
    </div>
  );
}