'use client';

import {
  Badge,
  Button,
  Card,
  Divider,
  Group,
  Loader,
  SimpleGrid,
  Stack,
  Text,
  Title,
} from '@mantine/core';
import { DateTimePicker } from '@mantine/dates';
import { IconPlayerTrackNext } from '@tabler/icons-react';
import { useEffect, useMemo, useState } from 'react';

import type { PipelineState } from '../types';

type PipelineKey = 'ingest' | 'recalc';

type RunRow = {
  id: string;
  pipeline: PipelineKey;
  trigger: 'cron' | 'manual';
  status: 'running' | 'success' | 'error';
  started_at: string;
  duration_ms: number | null;
  rows_processed: number | null;
  error_message: string | null;
};

type PipelinesLatest = { ingest: RunRow | null; recalc: RunRow | null };

function statusBadge(status: PipelineState['status']) {
  switch (status) {
    case 'running':
      return (
        <Badge
          variant="light"
          style={{ color: 'var(--color-accent)', background: 'rgba(217, 29, 84, 0.10)' }}
        >
          Running
        </Badge>
      );
    case 'error':
      return (
        <Badge variant="light" color="red">
          Error
        </Badge>
      );
    case 'paused':
      return (
        <Badge variant="light" style={{ color: 'var(--color-foreground-muted)' }}>
          Paused
        </Badge>
      );
    case 'idle':
    default:
      return (
        <Badge variant="light" style={{ color: 'var(--color-foreground-muted)' }}>
          Idle
        </Badge>
      );
  }
}

function fmtTime(iso?: string | null) {
  if (!iso) return '—';
  return iso.replace('T', ' ').replace('Z', '').slice(0, 19);
}

function fmtDuration(ms?: number | null) {
  if (!ms) return '—';
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}m ${r}s`;
}

// округляем вниз до часа в UTC
function floorToHourUTC(d: unknown) {
  // приводим к Date (если пришло не Date)
  const base = d instanceof Date ? d : new Date(String(d));
  if (Number.isNaN(base.getTime())) return null;

  // IMPORTANT:
  // берём компоненты, которые пользователь выбрал в пикере (локальные поля),
  // и создаём "такое же" время, но в UTC.
  const y = base.getFullYear();
  const m = base.getMonth();
  const day = base.getDate();
  const h = base.getHours();

  return new Date(Date.UTC(y, m, day, h, 0, 0, 0));
}

const BASE: Array<Pick<PipelineState, 'key' | 'title' | 'description'>> = [
  {
    key: 'ingest',
    title: 'Raw ingest',
    description: 'Забирает сырые данные и пишет их в raw-таблицы.',
  },
  {
    key: 'recalc',
    title: 'Recalc / aggregate',
    description: 'Считает статистику по raw-данным и сохраняет результат.',
  },
];

export function PipelinesPanel({ onRefresh }: { onRefresh: () => void }) {
  const [loading, setLoading] = useState(true);
  const [loadingKey, setLoadingKey] = useState<PipelineKey | null>(null);

  const [latest, setLatest] = useState<PipelinesLatest>({ ingest: null, recalc: null });

  const [manualFrom, setManualFrom] = useState<Record<PipelineKey, unknown | null>>({
    ingest: null,
    recalc: null,
  });
  
  const [manualTo, setManualTo] = useState<Record<PipelineKey, unknown | null>>({
    ingest: null,
    recalc: null,
  });

  async function load() {
    setLoading(true);
    try {
      const res = await fetch('/api/system/pipelines', { cache: 'no-store' });
      const json = await res.json();
      if (res.ok) setLatest(json.data);
      else console.error(json);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function runManual(pipeline: PipelineKey) {
    const from = manualFrom[pipeline];
    const to = manualTo[pipeline];
    if (!from || !to) return;
    
    const rangeFrom = floorToHourUTC(from);
    const rangeTo = floorToHourUTC(to);

    if (!rangeFrom || !rangeTo) {
      console.error('Invalid date input', { from, to });
      return;
    }

    try {
      setLoadingKey(pipeline);

      const res = await fetch('/api/system/ingest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          trigger: 'manual',
          pipeline,
          range_from: rangeFrom.toISOString(),
          range_to: rangeTo.toISOString(),
        }),
      });

      const data = await res.json().catch(() => null);
      if (!res.ok) {
        console.error('Manual run failed', data);
        return;
      }

      await load();
      onRefresh();
    } finally {
      setLoadingKey(null);
    }
  }

  const ui = useMemo(() => {
    return BASE.map((p) => {
      const run = latest[p.key];
      const status: PipelineState['status'] =
        run?.status === 'running' ? 'running' : run?.status === 'error' ? 'error' : 'idle';

      return {
        ...p,
        status,
        lastRun: run ? fmtTime(run.started_at) : '—',
        lastTrigger: run ? run.trigger : null,
        lastDuration: run ? fmtDuration(run.duration_ms) : '—',
        lastRows: run?.rows_processed ?? 0,
        lastError: run?.status === 'error' ? run.error_message ?? 'Error' : null,
      };
    });
  }, [latest]);

  return (
    <Stack gap="md">
      <Group justify="space-between" align="flex-end">
        <div>
          <Title order={3}>Pipelines</Title>
          <Text c="var(--color-foreground-muted)" size="sm" mt={4}>
            Scheduled (cron) и manual запуск — это разные триггеры одного пайплайна.
          </Text>
        </div>

        {loading ? <Loader size="sm" /> : null}
      </Group>

      <SimpleGrid cols={{ base: 1, sm: 2 }} spacing="md">
        {ui.map((p) => {
          const canRunManual = Boolean(manualFrom[p.key] && manualTo[p.key]);

          return (
            <Card key={p.key} padding="lg" radius="md" withBorder>
              <Stack gap="md">
                <div>
                  <Group gap="sm" align="center">
                    <Title order={4}>{p.title}</Title>
                    {statusBadge(p.status)}
                    <Badge variant="light" style={{ color: 'var(--color-foreground-muted)' }}>
                      Cron: coming soon
                    </Badge>
                  </Group>

                  <Text c="var(--color-foreground-muted)" size="sm" mt={6}>
                    {p.description}
                  </Text>

                  {p.lastError ? (
                    <Text size="xs" c="red" mt={6}>
                      {p.lastError}
                    </Text>
                  ) : null}
                </div>

                <SimpleGrid cols={2} spacing="xs">
                  <div>
                    <Text size="xs" c="var(--color-foreground-muted)">
                      Last run
                    </Text>
                    <Group gap={8}>
                      <Text fw={600}>{p.lastRun}</Text>
                      {p.lastTrigger ? (
                        <Badge variant="light" style={{ color: 'var(--color-foreground-muted)' }}>
                          {p.lastTrigger}
                        </Badge>
                      ) : null}
                    </Group>
                  </div>

                  <div>
                    <Text size="xs" c="var(--color-foreground-muted)">
                      Next scheduled
                    </Text>
                    <Text fw={600}>—</Text>
                  </div>

                  <div>
                    <Text size="xs" c="var(--color-foreground-muted)">
                      Last duration
                    </Text>
                    <Text fw={600}>{p.lastDuration}</Text>
                  </div>

                  <div>
                    <Text size="xs" c="var(--color-foreground-muted)">
                      Last processed rows
                    </Text>
                    <Text fw={600}>{p.lastRows.toLocaleString()}</Text>
                  </div>
                </SimpleGrid>

                <Group justify="flex-start">
                  <Button variant="outline" disabled>
                    Pause cron
                  </Button>
                  <Button variant="subtle" disabled>
                    Edit schedule
                  </Button>
                </Group>

                <Divider />

                <div>
                  <Text fw={600} mb={6}>
                    Manual run (UTC)
                  </Text>

                  <SimpleGrid cols={2} spacing="sm">
                    <DateTimePicker
                      label="From"
                      placeholder="Pick date & time"
                      value={manualFrom[p.key] as any}
                      onChange={(v) => setManualFrom((prev) => ({ ...prev, [p.key]: v }))}
                      clearable
                    />

                    <DateTimePicker
                      label="To"
                      placeholder="Pick date & time"
                      value={manualTo[p.key] as any}
                      onChange={(v) => setManualTo((prev) => ({ ...prev, [p.key]: v }))}
                      clearable
                    />
                  </SimpleGrid>

                  <Group justify="flex-end" mt="md">
                    <Button
                      leftSection={<IconPlayerTrackNext size={16} />}
                      loading={loadingKey === p.key}
                      disabled={!canRunManual}
                      onClick={() => runManual(p.key)}
                    >
                      Run manual
                    </Button>
                  </Group>

                  <Text size="xs" c="var(--color-foreground-muted)" mt={8}>
                    Время округляется вниз до часа (минуты игнорируются).
                  </Text>
                </div>
              </Stack>
            </Card>
          );
        })}
      </SimpleGrid>
    </Stack>
  );
}
