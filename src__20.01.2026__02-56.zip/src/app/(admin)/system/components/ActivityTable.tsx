'use client';

import { ActionIcon, Badge, Card, Group, Loader, ScrollArea, Table, Text, Title } from '@mantine/core';
import { IconEye } from '@tabler/icons-react';
import { useEffect, useState } from 'react';

type RunRow = {
  id: string;
  pipeline: 'ingest' | 'recalc';
  trigger: 'cron' | 'manual';
  status: 'running' | 'success' | 'error';
  started_at: string;
  finished_at: string | null;
  duration_ms: number | null;
  rows_processed: number | null;
  error_message: string | null;
  meta: any;
  range_from: string | null;
  range_to: string | null;

};

function resultBadge(status: RunRow['status']) {
  if (status === 'success') {
    return (
      <Badge
        variant="light"
        style={{ color: 'var(--color-accent)', background: 'rgba(217, 29, 84, 0.10)' }}
      >
        success
      </Badge>
    );
  }

  if (status === 'running') {
    return (
      <Badge variant="light" style={{ color: 'var(--color-foreground-muted)' }}>
        running
      </Badge>
    );
  }

  return (
    <Badge variant="light" color="red">
      error
    </Badge>
  );
}

function fmtDuration(ms: number | null) {
  if (!ms) return '—';
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}m ${r}s`;
}

function fmtTime(iso: string) {
  return iso.replace('T', ' ').replace('Z', '').slice(0, 19);
}

export function ActivityTable({ refreshKey }: { refreshKey: number }) {
  const [rows, setRows] = useState<RunRow[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch('/api/system/runs?limit=25', { cache: 'no-store' });
      const json = await res.json();
      if (res.ok) setRows(json.data ?? []);
      else console.error(json);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [refreshKey]);  

  return (
    <Card padding="lg" radius="md" withBorder>
      <Group justify="space-between" align="flex-end">
        <div>
          <Title order={3}>Recent activity</Title>
          <Text c="var(--color-foreground-muted)" size="sm" mt={4}>
            Последние запуски cron/manual из system_runs.
          </Text>
        </div>

        {loading ? <Loader size="sm" /> : null}
      </Group>

      <ScrollArea mt="md" h={260}>
        <Table striped highlightOnHover withTableBorder verticalSpacing="sm" horizontalSpacing="md">
          <thead>
            <tr>
              <th>Time</th>
              <th>Range (UTC)</th>
              <th>Pipeline</th>
              <th>Trigger</th>
              <th>Status</th>
              <th>Duration</th>
              <th>Rows</th>
              <th />
            </tr>
          </thead>

          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>
                  <Text size="sm">{fmtTime(r.started_at)}</Text>
                </td>
                <td>
                  <Text size="sm">
                    {r.range_from && r.range_to
                      ? `${fmtTime(r.range_from)} → ${fmtTime(r.range_to)}`
                      : '—'}
                  </Text>
                </td>
                <td>
                  <Text size="sm" fw={600}>
                    {r.pipeline}
                  </Text>
                  <Text size="xs" c="var(--color-foreground-muted)">
                    {r.status === 'error' ? r.error_message ?? 'Error' : '—'}
                  </Text>
                </td>
                <td>
                  <Text size="sm">{r.trigger}</Text>
                </td>
                <td>{resultBadge(r.status)}</td>
                <td>
                  <Text size="sm">{fmtDuration(r.duration_ms)}</Text>
                </td>
                <td>
                  <Text size="sm">{(r.rows_processed ?? 0).toLocaleString()}</Text>
                </td>
                <td>
                  <ActionIcon variant="subtle" aria-label="View log" disabled>
                    <IconEye size={18} />
                  </ActionIcon>
                </td>
              </tr>
            ))}

            {!loading && rows.length === 0 ? (
              <tr>
                <td colSpan={7}>
                  <Text size="sm" c="var(--color-foreground-muted)" ta="center" py="md">
                    No runs yet
                  </Text>
                </td>
              </tr>
            ) : null}
          </tbody>
        </Table>
      </ScrollArea>
    </Card>
  );
}
