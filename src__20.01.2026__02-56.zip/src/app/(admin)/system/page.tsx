'use client';

import { ScrollArea, Stack, Text, Title } from '@mantine/core';
import { useState } from 'react';

import { ActivityTable } from './components/ActivityTable';
import { HealthPanel } from './components/HealthPanel';
import { LogViewer } from './components/LogViewer';
import { MetricsCharts } from './components/MetricsCharts';
import { PipelinesPanel } from './components/PipelinesPanel';

export default function SystemPage() {
  const [refreshKey, setRefreshKey] = useState(0);

  function refresh() {
    setRefreshKey((k) => k + 1);
  }

  return (
    <ScrollArea h="calc(100vh - 140px)" type="auto" offsetScrollbars>
      <Stack gap="xl" pr="md">

        <HealthPanel />

        <PipelinesPanel onRefresh={refresh} />

        <ActivityTable refreshKey={refreshKey} />

        <LogViewer />

        <MetricsCharts />
      </Stack>
    </ScrollArea>
  );
}
