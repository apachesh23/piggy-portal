import { Title, Text } from '@mantine/core';

export default function TimeWorkedPage() {
  return (
    <div>
      <Title order={1}>Team Worked</Title>
      <Text c="var(--color-foreground-muted)" size="sm" mt={4}>
        COMING SOOM...
      </Text>
    </div>
  );
}