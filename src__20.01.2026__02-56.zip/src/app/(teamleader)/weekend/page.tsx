import { Title, Text } from '@mantine/core';

export default function WeekendPage() {
  return (
    <div>
      <Title order={1}>Weekend Schedule</Title>
      <Text c="var(--color-foreground-muted)" size="sm" mt={4}>
        COMING SOOM...
      </Text>
    </div>
  );
}

