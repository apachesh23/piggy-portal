import { Title, Text } from '@mantine/core';

export default function TimeWorkedPage() {
  return (
    <div>
      <Title order={1} mb="lg">Time Worked</Title>
      <Text>Здесь будет учет отработанного времени</Text>
    </div>
  );
}