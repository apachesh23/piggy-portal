import { Title, Text } from '@mantine/core';

export default function WeekendPage() {
  return (
    <div>
      <Title order={1} mb="lg">Weekend Schedule</Title>
      <Text>Здесь будет календарь выходных</Text>
    </div>
  );
}