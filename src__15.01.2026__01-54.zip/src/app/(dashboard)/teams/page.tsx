import { Title, Text } from '@mantine/core';

export default function TeamsPage() {
  return (
    <div>
      <Title order={1} mb="lg">Teams</Title>
      <Text>Здесь будет дерево команд</Text>
    </div>
  );
}