import { Title, Text } from '@mantine/core';

export default function ReportsPage() {
  return (
    <div>
      <Title order={1} mb="lg">Reports</Title>
      <Text>Здесь будет отчетность команды</Text>
    </div>
  );
}